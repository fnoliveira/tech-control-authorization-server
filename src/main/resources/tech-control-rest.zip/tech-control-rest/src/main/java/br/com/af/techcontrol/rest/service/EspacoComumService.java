package br.com.af.techcontrol.rest.service;

import java.util.List;

import br.com.af.techcontrol.rest.entity.condominio.EspacoComum;
import br.com.af.techcontrol.rest.service.base.CrudService;

public interface EspacoComumService extends CrudService<EspacoComum, Long> {

	List<EspacoComum> findAll();

	EspacoComum save(EspacoComum espacoComum);

	EspacoComum findByNome(String nome);

	List<EspacoComum> findByCondominio(Long condominioId);

	EspacoComum findOne(Long id);

	void delete(Long id);

	void save(List<EspacoComum> espacosComum);

}