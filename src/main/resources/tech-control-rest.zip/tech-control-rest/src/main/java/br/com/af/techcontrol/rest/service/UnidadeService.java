package br.com.af.techcontrol.rest.service;

import java.util.List;

import br.com.af.techcontrol.rest.entity.condominio.Unidade;
import br.com.af.techcontrol.rest.service.base.CrudService;

public interface UnidadeService extends CrudService<Unidade, Long>{

	List<Unidade> findAll();

	List<Unidade> saveAll(List<Unidade> unidades);

	Unidade save(Unidade unidades);

	List<Unidade> save(List<Unidade> unidades);

	Unidade findOne(Long id);

	List<Unidade> findByBlocoId(Long blocoId);

}