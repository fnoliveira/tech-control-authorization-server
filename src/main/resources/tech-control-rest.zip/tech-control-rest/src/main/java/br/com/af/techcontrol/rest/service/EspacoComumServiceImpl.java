package br.com.af.techcontrol.rest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.af.techcontrol.rest.entity.condominio.EspacoComum;
import br.com.af.techcontrol.rest.repository.EspacoComumRepository;
import br.com.af.techcontrol.rest.service.base.AbstractService;

@Service
@Transactional
public class EspacoComumServiceImpl extends AbstractService<EspacoComum, Long> implements EspacoComumService {

	@Autowired
	EspacoComumRepository repository;

	@Override
	public List<EspacoComum> findAll() {
		return repository.findAll();
	}

	@Override
	public EspacoComum save(EspacoComum espacoComum) {
		return repository.save(espacoComum);
	}

	@Override
	public EspacoComum findByNome(String nome) {
		return repository.findByNome(nome);
	}

	@Override
	public List<EspacoComum> findByCondominio(Long condominioId) {
		return repository.findByCondominio(condominioId);
	}

	@Override
	public EspacoComum findOne(Long id) {
		return repository.findOne(id);
	}

	@Override
	public void delete(Long id) {
		repository.delete(id);
	}

	@Override
	public void save(List<EspacoComum> espacosComum) {
		repository.save(espacosComum);
	}

}
