package br.com.af.techcontrol.rest.entity.base.validation.group;

public interface CpfGroup {

}
