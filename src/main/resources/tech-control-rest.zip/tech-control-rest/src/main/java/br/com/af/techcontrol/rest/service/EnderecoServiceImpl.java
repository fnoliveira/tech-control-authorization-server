package br.com.af.techcontrol.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.af.techcontrol.rest.entity.base.Endereco;
import br.com.af.techcontrol.rest.repository.EnderecoRepository;
import br.com.af.techcontrol.rest.service.base.AbstractService;

@Service
public class EnderecoServiceImpl extends AbstractService<Endereco, Long> implements EnderecoService{

	@Autowired
	EnderecoRepository repository;

	@Override
	@Transactional
	public Endereco save(Endereco endereco) {
		return repository.save(endereco);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Endereco> findAll() {
		return repository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Endereco findById(Long id) {
		return repository.findOne(id);
	}

	@Override
	public Endereco createEndereco(String cep, String logradouro, String numero, String complemento, String bairro,
			String cidade, String uf) {

		Endereco endereco = new Endereco(cep, logradouro, numero, complemento, bairro, cidade, uf, "BR", true);
		return save(endereco);
	}
}
