package br.com.af.techcontrol.rest.service;

import br.com.af.techcontrol.rest.entity.base.Pessoa;
import br.com.af.techcontrol.rest.service.base.CrudService;

public interface PessoaService extends CrudService<Pessoa, Long>{

	void createPessoaIfNotFound(Pessoa pessoa);

	Pessoa save(Pessoa pessoa);

}