package br.com.af.techcontrol.rest.service;

import br.com.af.techcontrol.rest.entity.base.Contato;
import br.com.af.techcontrol.rest.service.base.CrudService;

public interface ContatoService extends CrudService<Contato, Long>{

	Contato save(Contato contato);

}