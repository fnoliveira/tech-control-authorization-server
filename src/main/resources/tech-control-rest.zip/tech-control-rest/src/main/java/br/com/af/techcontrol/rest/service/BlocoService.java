package br.com.af.techcontrol.rest.service;

import java.util.List;

import br.com.af.techcontrol.rest.entity.condominio.Bloco;
import br.com.af.techcontrol.rest.service.base.CrudService;

public interface BlocoService extends CrudService<Bloco, Long> {

	List<Bloco> findAll();

	Bloco save(Bloco bloco);

	Bloco findOne(Long id);

	void save(List<Bloco> blocos);

}