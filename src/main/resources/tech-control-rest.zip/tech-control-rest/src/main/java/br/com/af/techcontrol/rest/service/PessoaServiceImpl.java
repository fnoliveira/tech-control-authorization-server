package br.com.af.techcontrol.rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.af.techcontrol.rest.entity.base.Pessoa;
import br.com.af.techcontrol.rest.repository.PessoaRepository;
import br.com.af.techcontrol.rest.service.base.AbstractService;

@Service
public class PessoaServiceImpl extends AbstractService<Pessoa, Long> implements PessoaService{

	@Autowired
	PessoaRepository pessoaRepository;

	/* (non-Javadoc)
	 * @see br.com.af.techcontrol.rest.service.PessoaService#createPessoaIfNotFound(br.com.af.techcontrol.rest.entity.base.Pessoa)
	 */
	@Override
	@Transactional(readOnly = true)
	public void createPessoaIfNotFound(Pessoa pessoa) {
		pessoaRepository.save(pessoa);
	}
	
	/* (non-Javadoc)
	 * @see br.com.af.techcontrol.rest.service.PessoaService#save(br.com.af.techcontrol.rest.entity.base.Pessoa)
	 */
	@Override
	@Transactional
	public Pessoa save(Pessoa pessoa) {
		return pessoaRepository.save(pessoa);
	}

}
