package br.com.af.techcontrol.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.af.techcontrol.rest.entity.condominio.Bloco;
import br.com.af.techcontrol.rest.repository.BlocoRepository;
import br.com.af.techcontrol.rest.service.base.AbstractService;

@Service
public class BlocoServiceImpl extends AbstractService<Bloco, Long> implements BlocoService{

	@Autowired
	BlocoRepository repository;

	@Override
	@Transactional(readOnly = true)
	public List<Bloco> findAll() {
		return repository.findAll();
	}

	@Override
	@Transactional
	public Bloco save(Bloco bloco) {
		return repository.save(bloco);
	}

	@Override
	@Transactional(readOnly = true)
	public Bloco findOne(Long id) {
		return repository.findOne(id);
	}

	@Override
	@Transactional
	public void save(List<Bloco> blocos) {
		repository.save(blocos);
	}

}
