package br.com.af.techcontrol.rest.service;

import java.util.List;

import br.com.af.techcontrol.rest.entity.base.Telefone;
import br.com.af.techcontrol.rest.service.base.CrudService;

public interface TelefoneService extends CrudService<Telefone, Long>{

	List<Telefone> findAll();

	Telefone save(Telefone telefone);

	Telefone findOne(Long id);

}